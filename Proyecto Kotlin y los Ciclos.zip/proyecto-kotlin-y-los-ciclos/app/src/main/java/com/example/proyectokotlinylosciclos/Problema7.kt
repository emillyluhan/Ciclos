package com.example.proyectokotlinylosciclos

// Nombre: Emilly Luhan Martinez Osorio
// Fecha: 13/02/2025
// Descripción: Solución del Problema 1 de la guía de Kotlin y los ciclos

// Función principal
fun main() {
    problema7()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema7() {
    // Leemos el valor de N desde la entrada
    val N = readLine()!!.toInt()

    // Si N es menor o igual a 0, imprimimos "Error"
    if (N <= 0) {
        println("N:")
        println("Error")
    } else {
        // Si N es mayor que 0, calculamos la suma de los cubos
        var suma = 0
        for (i in 1..N) {
            suma += i * i * i  // Calculamos i^3 y sumamos
        }
        // Imprimimos el valor de N y la suma
        println("N:")
        println("s = $suma")
    }
}
