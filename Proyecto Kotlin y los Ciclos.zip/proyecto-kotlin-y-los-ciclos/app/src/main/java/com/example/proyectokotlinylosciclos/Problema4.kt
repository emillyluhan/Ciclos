package com.example.proyectokotlinylosciclos

// Nombre: Emilly Luhan Martinez Osorio
// Fecha: 13/02/2025
// Descripción: Solución del Problema 1 de la guía de Kotlin y los ciclos

// Función principal
fun problema4() {
    var maxNum = Int.MIN_VALUE  // Empezamos con el valor más bajo posible
    var maxIndex = 0  // El índice donde se encuentra el número máximo
    var index = 1  // Empezamos el conteo de índices desde 1

    while (true) {
        println("n:")
        val num = readLine()!!.toInt()

        if (num == 0) break  // Terminamos cuando el número es 0

        // Si encontramos un número mayor, actualizamos el máximo
        if (num > maxNum) {
            maxNum = num
            maxIndex = index  // Guardamos el índice del número máximo
        }
        index++  // Incrementamos el índice
    }

    // Imprimimos el índice del número más grande
    println("Posición del mayor = $maxIndex")
}
