package com.example.proyectokotlinylosciclos

// Nombre: Emilly Luhan Martinez Osorio
// Fecha: 13/02/2025
// Descripción: Solución del Problema 1 de la guía de Kotlin y los ciclos

// Función principal
fun main() {
    problema10()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema10() {
    // Leemos el valor de n desde la entrada
    val n = readLine()!!.toInt()

    // Imprimimos "n:" antes de cualquier salida
    println("n:")

    // Si n no está dentro del rango permitido (1 <= n <= 9), imprimimos "Error"
    if (n <= 0 || n > 9) {
        println("Error")
        return
    }

    // Imprimir la escalera de números
    for (i in 1..n) {
        for (j in 1..i) {
            print(j) // Imprimir los números del 1 al i
        }
        println() // Salto de línea
    }
}