package com.example.proyectokotlinylosciclos

// Nombre: Emilly Luhan Martinez Osorio
// Fecha: 13/02/2025
// Descripción: Solución del Problema 1 de la guía de Kotlin y los ciclos

fun problema1() {
    // Leemos el valor de N desde la entrada estándar
    println("Ingresa N:")
    val N = readLine()!!.toInt()  // Leemos N como entero

    var i = 1
    val result = mutableListOf<Int>()

    // Calculamos los cuadrados de los números enteros mientras el cuadrado sea menor o igual a N
    while (i * i <= N) {
        result.add(i * i)  // Añadimos el cuadrado a la lista
        i++  // Incrementamos i para el siguiente número
    }

    // Imprimimos los resultados en formato de espacio, separados por espacio
    print(result.joinToString(" ") + " ")  // Imprimimos todos los cuadrados
}
