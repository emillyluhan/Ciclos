package com.example.proyectokotlinylosciclos

// Nombre: Emilly Luhan Martinez Osorio
// Fecha: 13/02/2025
// Descripción: Solución del Problema 1 de la guía de Kotlin y los ciclos

fun problema2() {
    // Leemos las entradas
    println("Ingresa x:")
    val x = readLine()!!.toInt()
    println("Ingresa y:")
    val y = readLine()!!.toInt()

    var distancia = x.toDouble()  // Distancia inicial
    var dias = 1  // Comienza el primer día

    // Mientras no se haya alcanzado la distancia necesaria
    while (distancia < y) {
        distancia *= 1.10  // Aumento del 10% cada día
        dias++  // Aumentamos el contador de días
    }

    // Imprimimos el resultado
    println("Necesitas $dias días para correr bien los $y Km")
}
