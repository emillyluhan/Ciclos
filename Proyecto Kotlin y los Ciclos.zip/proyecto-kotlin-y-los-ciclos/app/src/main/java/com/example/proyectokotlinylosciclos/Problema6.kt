package com.example.proyectokotlinylosciclos

// Nombre: Emilly Luhan Martinez Osorio
// Fecha: 13/02/2025
// Descripción: Solución del Problema 1 de la guía de Kotlin y los ciclos

// Función principal
fun main() {
    problema6()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema6() {
    // Leemos los valores de A y B desde la entrada estándar
    println("A:")
    val A = readLine()!!.toInt()
    println("B:")
    val B = readLine()!!.toInt()

    // Creamos una lista mutable para guardar los números entre A y B
    val result = mutableListOf<Int>()

    // Si A es menor que B, imprimimos en orden ascendente
    if (A < B) {
        var i = A
        while (i <= B) {
            result.add(i)
            i++  // Incrementamos i
        }
    }
    // Si A es mayor o igual que B, imprimimos en orden descendente
    else {
        var i = A
        while (i >= B) {
            result.add(i)
            i--  // Decrementamos i
        }
    }

    // Imprimimos los resultados en formato de espacio, separados por espacio
    println(result.joinToString(" ") + " ")
}

