package com.example.proyectokotlinylosciclos

// Nombre: Emilly Luhan Martinez Osorio
// Fecha: 13/02/2025
// Descripción: Solución del Problema 1 de la guía de Kotlin y los ciclos

// Función principal
fun main() {
    problema8()
}

// Función que debe desarrollar la lógica para la solución del problema
fun problema8() {
    // Leemos el valor de n desde la entrada
    val n = readLine()!!.toInt()

    // Inicializamos la variable que guardará el factorial
    var resultado = 1

    // Si n es mayor que 0, calculamos el factorial
    if (n == 0) {
        resultado = 1 // El factorial de 0 es 1
    } else {
        for (i in 1..n) {
            resultado *= i // Multiplicamos cada número desde 1 hasta n
        }
    }

    // Imprimimos el resultado en el formato esperado
    println("n:")
    println("$n ! = $resultado")
}
