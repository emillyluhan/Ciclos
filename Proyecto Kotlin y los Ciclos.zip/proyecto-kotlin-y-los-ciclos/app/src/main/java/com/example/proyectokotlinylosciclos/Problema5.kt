package com.example.proyectokotlinylosciclos

// Nombre: Emilly Luhan Martinez Osorio
// Fecha: 13/02/2025
// Descripción: Solución del Problema 1 de la guía de Kotlin y los ciclos

// Función principal
fun main() {
    problema5()
}

fun problema5() {
    var countPares = 0
    while (true) {
        println("n:")
        val num = readLine()!!.toInt()
        if (num == -1) break
        if (num % 2 == 0) countPares++
    }
    println("Pares = $countPares")
}