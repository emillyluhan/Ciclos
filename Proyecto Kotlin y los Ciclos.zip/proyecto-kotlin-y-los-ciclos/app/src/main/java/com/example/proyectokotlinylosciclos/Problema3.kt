package com.example.proyectokotlinylosciclos

// Nombre: Emilly Luhan Martinez Osorio
// Fecha: 13/02/2025
// Descripción: Solución del Problema 1 de la guía de Kotlin y los ciclos

fun problema3() {
    var sum = 0
    var num: Int

    // Leemos números hasta encontrar un 0
    do {
        println("n:")
        num = readLine()!!.toInt()  // Leemos el número
        sum += num  // Sumamos el número a la suma total
    } while (num != 0)  // Continuamos hasta que leemos un 0

    // Imprimimos la suma total (sin contar el 0)
    println("Suma = $sum")
}
